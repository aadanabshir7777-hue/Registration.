XOG URURIN — GITHUB PAGES (BILAASH)

Sida loo publish-gareeyo adigoo isticmaalaya telefoonka:
1. Ka fur repository-gaaga GitHub.
2. Riix Add file → Upload files.
3. Ka soo saar ZIP-kan telefoonkaaga (Extract), kadib geli faylka index.html ee ku jira.
4. Faylka index.html ku geli meesha ugu weyn ee repository-ga (root), isla meesha aad ku aragto Code.
5. Riix Commit changes.
6. Tag Settings → Pages.
7. Under Build and deployment, dooro Deploy from a branch.
8. Branch: main; Folder: /(root); kadib Save.
9. Sug dhowr daqiiqo, GitHub Pages ayaa ku tusi doona website link.

MUHIIM: GitHub Pages waa bog static ah. Noocan wuxuu muujinayaa naqshadda website-ka, laakiin ma kaydiyo xogta dadka, mana shaqaysiiyo login/register dhab ah. Ha ka codsan dadka inay geliyaan password ay isticmaalaan. Si xogta loo kaydiyo, waxaa loo baahan yahay adeeg backend/database ama foom adeeg gaar ah leh.
